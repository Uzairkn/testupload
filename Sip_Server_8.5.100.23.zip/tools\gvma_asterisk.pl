#!/usr/bin/perl -w
#!perl.exe 
################################################################################################
# Genesys Telecommunication Labaratories, Inc.                                                 # 
# An Alcatel Company                                                                           #
#                                                                                              #
# Uses the SOAP:::Lite package to connect to Configuration Server on SOAP port in order to     #
# retrieve TServers data.                                                                      #
#                                                                                              #
################################################################################################

use HTTP::Cookies;
#use SOAP::Lite+trace; #Don't use in production
use SOAP::Lite;
use File::Copy;
use Net::Telnet ();

use constant CFGFILENAME                       => 'gvma_asterisk.cfg';

use constant CFGSERVERSECTION                  => 'cfgserver';
use constant CFGSERVEROPTIONHOST               => 'host';
use constant CFGSERVEROPTIONPORT               => 'port';
use constant CFGSERVEROPTIONUSER               => 'username';
use constant CFGSERVEROPTIONPSSW               => 'password';
use constant CFGSERVERDNQUERY    			   => 'dnquery';
use constant CFGSERVERAGENTQUERY   			   => 'agentquery';
use constant CFGSERVERAGENTGROUPQUERY		   => 'agentgroupquery';

use constant GVMA_ASTERISK_VMOPTIONS           => 'gvma_asterisk_vmoptions';
use constant GVMA_OPT_SECTIONNAME  			   => 'annexsectionname';
use constant GVMA_OPTNAME_MAILBOX			   => 'optname_mailbox';
use constant GVMA_OPTNAME_NAME				   => 'optname_name';
use constant GVMA_OPTNAME_PASSWORD			   => 'optname_password';
use constant GVMA_OPTNAME_EMAIL				   => 'optname_email';
use constant GVMA_OPTNAME_PAGER_EMAIL		   => 'optname_pager_email';
use constant GVMA_OPTNAME_OPTIONS			   => 'optname_options';

use constant GVMA_SETTINGS					   => 'gvma_settings';
use constant GVMA_ASTERISK_CFG_PATH             => 'asterisk_cfg_path';
use constant GVMA_ASTERISK_CFG_FILE_VM          => 'asterisk_cfg_file_vm';
use constant GVMA_ASTERISK_CFG_FILE_SIP         => 'asterisk_cfg_file_sip';
use constant GVMA_ASTERISK_CFG_GVMA_BEGIN       => 'asterisk_cfg_gvma_begin';
use constant GVMA_ASTERISK_CFG_GVMA_END         => 'asterisk_cfg_gvma_end';
use constant GVMA_BACKUP_PATH			=> 'backup_path';
use constant GVMA_VMPREFIX			=> 'vm_ext_prefix';

use constant GVMA_CFGRESPONSEPATHDN             => '/Envelope/Body/getResponse/result/CfgData/CfgDN';
use constant GVMA_CFGRESPONSEPATHAGENT          => '/Envelope/Body/getResponse/result/CfgData/CfgAgentLogin';
use constant GVMA_CFGRESPONSEPATHAGENTGROUP     => '/Envelope/Body/getResponse/result/CfgData/CfgAgentGroup';


use constant GVMA_ASTERISK_CM_PORT              => 'asterisk_cm_port';
use constant GVMA_ASTERISK_CM_USER              => 'asterisk_cm_user';
use constant GVMA_ASTERISK_CM_PASWD             => 'asterisk_cm_password';



# log file setup 
my $log_file;
my ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time) ;
$Month ++ ;
$Year += 1900 ;
my $datestamp = $Month."-".$Day."-".$Year."-".$Hour."-".$Minute."-".$Second;
$log_file = ">" . "gvma_asterisk_" . $datestamp . ".log";
open(LOGF,$log_file) || die("ERROR: Can not open $log_file because $!\n");


#Configuration login params  
my ($host, $port, $user, $passwd, $cfgdnquery, $cfgagentquery, $cfgagentgroupquery);
my ($gvma_opt_sectionname, $gvma_opt_mailbox, $gvma_opt_pasword, $gvma_opt_name, $gvma_opt_email, $gvma_opt_pager_email,$gvma_opt_options);
my ($gvma_cfg_path,$gvma_cfg_file_vm,$gvma_cfg_file_sip,$gvma_cfg_begin,$gvma_cfg_end,$gvma_backup_path,$gvma_vmprefix);

print LOGF "\n############################################################################";
print LOGF "\n#                                                                          #";
print LOGF "\n# Genesys VoiceMail Configuration Adapter for Asterisk. Version 7.5.000.02 #";
print LOGF "\n# Copyright (c) 1997-2006 Genesys Telecommunications Laboratories, Inc.    #";
print LOGF "\n#                                                                          #";
print LOGF "\n############################################################################";
print LOGF "\n\n";

# ###############################################################################
# Check the env the script is running in - die if it's not set properly 
ChkEnv();

# ###############################################################################
# Retrieve parameters from configuration file

$host = GetCfgOption(CFGSERVERSECTION, CFGSERVEROPTIONHOST);
$port = GetCfgOption(CFGSERVERSECTION, CFGSERVEROPTIONPORT);
$user = GetCfgOption(CFGSERVERSECTION, CFGSERVEROPTIONUSER);
$passwd = GetCfgOption(CFGSERVERSECTION,CFGSERVEROPTIONPSSW); 
$cfgdnquery = GetCfgOption(CFGSERVERSECTION, CFGSERVERDNQUERY);
$cfgagentquery = GetCfgOption(CFGSERVERSECTION, CFGSERVERAGENTQUERY);
$cfgagentgroupquery = GetCfgOption(CFGSERVERSECTION, CFGSERVERAGENTGROUPQUERY);

$gvma_opt_sectionname = GetCfgOption(GVMA_ASTERISK_VMOPTIONS, GVMA_OPT_SECTIONNAME);
$gvma_opt_mailbox = GetCfgOption(GVMA_ASTERISK_VMOPTIONS, GVMA_OPTNAME_MAILBOX );
$gvma_opt_name = GetCfgOption(GVMA_ASTERISK_VMOPTIONS, GVMA_OPTNAME_NAME );
$gvma_opt_pasword = GetCfgOption(GVMA_ASTERISK_VMOPTIONS, GVMA_OPTNAME_PASSWORD );
$gvma_opt_email = GetCfgOption(GVMA_ASTERISK_VMOPTIONS, GVMA_OPTNAME_EMAIL );
$gvma_opt_pager_email = GetCfgOption(GVMA_ASTERISK_VMOPTIONS, GVMA_OPTNAME_PAGER_EMAIL );
$gvma_opt_options = GetCfgOption(GVMA_ASTERISK_VMOPTIONS, GVMA_OPTNAME_OPTIONS );

$gvma_cfg_path = GetCfgOption(GVMA_SETTINGS, GVMA_ASTERISK_CFG_PATH);
$gvma_cfg_file_vm = GetCfgOption(GVMA_SETTINGS, GVMA_ASTERISK_CFG_FILE_VM);
$gvma_cfg_file_sip = GetCfgOption(GVMA_SETTINGS, GVMA_ASTERISK_CFG_FILE_SIP);
$gvma_cfg_begin = GetCfgOption(GVMA_SETTINGS, GVMA_ASTERISK_CFG_GVMA_BEGIN);
$gvma_cfg_end = GetCfgOption(GVMA_SETTINGS, GVMA_ASTERISK_CFG_GVMA_END);
$gvma_backup_path = GetCfgOption(GVMA_SETTINGS, GVMA_BACKUP_PATH);
$gvma_vmprefix = GetCfgOption(GVMA_SETTINGS, GVMA_VMPREFIX);

$gvma_asterisk_cm_port = GetCfgOption(GVMA_SETTINGS, GVMA_ASTERISK_CM_PORT);
$gvma_asterisk_cm_user = GetCfgOption(GVMA_SETTINGS, GVMA_ASTERISK_CM_USER);
$gvma_asterisk_cm_pswd = GetCfgOption(GVMA_SETTINGS, GVMA_ASTERISK_CM_PASWD);


my $end_point = "http://".$host.":".$port;
my %ghash_of_tservers;

my @voicemail_buff;				# Voicemail configuration buffer
my @sip_buff;					# SIP configuration buffer

# ###############################################################################
# Connect to Config Server 

print LOGF "\nConnecting to Configurtion Server on host=$host, soap-port=$port..\n";
$cookie_jar = HTTP::Cookies->new(ignore_discard => 1);
$s = SOAP::Lite
  ->proxy($end_point,cookie_jar => $cookie_jar )
  ->deserializer(SOAP::Custom::XML::Deserializer->new);

my $soap_response = $s->registerInternal( SOAP::Data->name(userName => $user),
                                          SOAP::Data->name(userPassword => $passwd),	
                                          SOAP::Data->name(applicationName => 'default') );

# tbd: check reg result 
print LOGF "\nConnected to configuration server.\n";
 

# ###############################################################################   

# Create backup copies
my $original_file;
my $backup_file;
my $original_file_sip;
my $backup_file_sip;
my $in_file;
my $out_file;
my $in_line;
my $in_state;
my $reload;

# voicemail configuration 
$original_file = $gvma_cfg_path . "/" . $gvma_cfg_file_vm;
$backup_file = $gvma_backup_path . "/" . $gvma_cfg_file_vm . "_" . $datestamp;
print LOGF "Copying: " . $original_file . " to " . $backup_file . "\n";
copy($original_file,$backup_file) || die("\nERROR: Cannot create backup copy of the file " . $original_file . ": $!\n");

# sip configuration 
$original_file_sip = $gvma_cfg_path . "/" . $gvma_cfg_file_sip;
$backup_file_sip = $gvma_backup_path . "/" . $gvma_cfg_file_sip . "_" . $datestamp;
print LOGF "Copying: " . $original_file_sip . " to " . $backup_file_sip . "\n";
copy($original_file_sip,$backup_file_sip) || die("\nERROR: Cannot create backup copy of the file " . $original_file_sip . ": $!\n");

print LOGF "Backup copies created ...\n";

# Process configuration data, store result in buffers
ProcessConfiguration();

print LOGF "Configuration processed ...\n";

# Update voice mail configuration  
$in_file = $gvma_cfg_path . "/" . $gvma_cfg_file_vm . "__";
copy($original_file,$in_file) || die("ERROR: Cannot copy file " . $original_file . ": $!\n");
$out_file = ">" . $original_file;
open(INF,$in_file) || die("ERROR: Can not open $in_file because $!\n");
open(OUTF,$out_file) || die("ERROR: Can not open $out_file because $!\n");
binmode(OUTF);

$in_state = 0;

# Load input file until delimiter found
while(<INF>) 
{
   $in_line = $_;
   if ( ($in_state==0) && (index($in_line,$gvma_cfg_begin) == 0) )
   {
		# found start delimiter, from now on skip content 
   		print OUTF $in_line;
		$in_state = 1;
   }
   elsif ( ($in_state==1) && ( index($in_line,$gvma_cfg_end) == 0) )
   {
		# found end delimiter, generate content 
   		print OUTF "; Generated by Genesys VoiceMail Configuration Adapter for Asterisk.\n";
   		print OUTF "; Content generated at " . localtime(time) . "\n";
   		print OUTF "\n";
		my $bl;
		while( @voicemail_buff > 0 )
		{
			$bl = shift(@voicemail_buff);
			print OUTF $bl;
		}	
		$in_state = 2;
   		print OUTF $in_line; 
   }
   elsif ( ($in_state == 0) || ($in_state == 2) )
   {
   		print OUTF $in_line;
   }
}   
close(INF);
close(OUTF);
   
# Update sip configuration  
$in_file = $gvma_cfg_path . "/" . $gvma_cfg_file_sip . "__";
copy($original_file_sip,$in_file) || die("ERROR: Cannot copy file " . $original_file_sip . ": $!\n");
$out_file = ">" . $original_file_sip;
open(INF,$in_file) || die("ERROR: Can not open $in_file because $!\n");
open(OUTF,$out_file) || die("ERROR: Can not open $out_file because $!\n");
binmode(OUTF);

$in_state = 0;
# Load input file until delimiter found
while(<INF>) 
{
   $in_line = $_;
   if ( ($in_state==0) && (index($in_line,$gvma_cfg_begin) == 0) )
   {
		# found start delimiter, from now on skip content 
   		print OUTF $in_line;
		$in_state = 1;
   }
   elsif ( ($in_state==1) && ( index($in_line,$gvma_cfg_end) == 0) )
   {
		# found end delimiter, generate content 
   		print OUTF "; Generated by Genesys VoiceMail Configuration Adapter for Asterisk.\n";
   		print OUTF "; Content generated at " . localtime(time) . "\n";
   		print OUTF "\n";
		my $bl;
		while( @sip_buff > 0 )
		{
			$bl = shift(@sip_buff);
			print OUTF $bl;
		}	
		$in_state = 2;
   		print OUTF $in_line; 
   }
   elsif ( ($in_state == 0) || ($in_state == 2) )
   {
   		print OUTF $in_line;
   }
}   
close(INF);
close(OUTF);

if($reload)
{
print LOGF "Reloading Asterisk configuration...\n";

  $tn = new Net::Telnet (Port => $gvma_asterisk_cm_port,
		      Prompt => '/.*[\$%#>] $/',
		      Output_record_separator => '',
		      Errmode    => 'return'
		     );
  print LOGF "Connecting to Asterisk Manager Interface ...\n";
  $tn->open(Host => "localhost", Port => $gvma_asterisk_cm_port , Timeout => 100);
  $tn->waitfor('/0\n$/') or die "Unable to open connection to Asterisk Manager interface. Verify Port #.";
  
   $command = "ACTION: LOGIN\n"
              ."USERNAME: ". $gvma_asterisk_cm_user . "\n"
              ."SECRET: " . $gvma_asterisk_cm_pswd . "\n"
              ."EVENTS: ON\n\n"; 
	
  $tn->print($command );
  $tn->waitfor('/Authentication accept*/')
    or die "Asterisk Manager Interface login failed, verify username and password: ", $tn->lastline;
  print LOGF "Connected to Asterisk Manager Interface as : ". $gvma_asterisk_cm_user ."\n";        
#Send Reload Command
  $command = "ACTION: COMMAND\n"
             . "command: reload\n\n"; 
  $tn->print($command);
# wait for asterisk to start reload
  
  $tn->waitfor('/Event: Reload.*/') or die "Unable to determine reloading execution ", $tn->lastline;
  print LOGF "Astrisk configuration reloaded: ". localtime(time) . "\n";
  $command = "ACTION: LOGOFF\n\n";
  $tn->print($command);

  $tn->close();
}
    else
    {
     print LOGF "\nNOT reloaded.Asterisk is not running...\nConfiguration will be loaded at Asterisk start.\n";   
    }

print LOGF "DONE\n";


sub ProcessConfiguration
{
	ProcessConfigurationDN();
	ProcessConfigurationAgent();
	ProcessConfigurationAgentGroup();
}

sub ProcessConfigurationDN
{
   my $ttl = "\n; ######## Voice Mail Boxes for the Extensions #######\n\n";
   push(@voicemail_buff,$ttl);

   # Retrieves all necessary objects from Configuration Server. 
   my $qry = $cfgdnquery;
   my $dns_dataset = $s->get(SOAP::Data->name(query => $qry )); 
   my $cntr = 0;
   my $vmboxcfg = '';
   my $sipextcfg = '';

   # VoiceMail Box options 
   my $gvma_mailbox = '';
   my $gvma_pasword = '';
   my $gvma_name = '';
   my $gvma_email = '';
   my $gvma_pager_email = '';
   my $gvma_options = '';
   
   print LOGF "Executing query: " . $qry . "\n";
   print LOGF "Retrieving Extensions, started: " . localtime(time) . "\n";

   foreach my $dn ($dns_dataset->valueof(GVMA_CFGRESPONSEPATHDN)) 
   {
		print LOGF "Processing Extension: " . $dn->name->value . " ...";

		# setup default values for mailbox options 
		$gvma_mailbox = $dn->name->value;		# the same as DN
		$gvma_pasword = $dn->name->value;		# the same as DN
		$gvma_name = $dn->name->value;			# the same as DN 
		$gvma_email = '';						# empty
		$gvma_pager_email = '';					# empty
		$gvma_options = '';						# empty 
		
		if( defined($dn->userProperties) && defined($dn->userProperties->list_pair) )
		{
			foreach my $section ($dn->userProperties->list_pair )   
			{
					# print LOGF "\tProcessing Section: " . $section->key . "\n";
     				if( $section->key eq $gvma_opt_sectionname )
     				{
						foreach my $option ($section->str_pair )   
						{
   							if( $option->{'_attr'}->{'key'} eq $gvma_opt_mailbox )
							{
								$gvma_mailbox = $option->{'_attr'}->{'value'};
							}
							elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_pasword )
							{
								$gvma_pasword = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_name )
							{
								$gvma_name = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_email )
							{
								$gvma_email = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_pager_email )
							{
								$gvma_pager_email = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_options )
							{
								$gvma_options = $option->{'_attr'}->{'value'};
							}
						}
     				}
			}
		}

		# Map options to VoiceMail Box configuration line 
		$vmboxcfg = $gvma_mailbox . " => ";
		$vmboxcfg = $vmboxcfg . $gvma_pasword . ",";
		$vmboxcfg = $vmboxcfg . $gvma_name . ",";
		$vmboxcfg = $vmboxcfg . $gvma_email . ",";
		$vmboxcfg = $vmboxcfg . $gvma_pager_email . ",";
		$vmboxcfg = $vmboxcfg . $gvma_options . "\n";
		push(@voicemail_buff,$vmboxcfg);
		print LOGF "\n>>>> voicemail.cfg <<<<\n" . $vmboxcfg . "\n";

		# Map options to Asterisk SIP extension configuration 
		$sipextcfg = "[" . $gvma_mailbox . "]\n";
		$sipextcfg = $sipextcfg . "type=friend\n";
		$sipextcfg = $sipextcfg . "host=dynamic\n";
		$sipextcfg = $sipextcfg . "mailbox=" . $gvma_mailbox . "\n\n";
		push(@sip_buff,$sipextcfg);
		print LOGF "\n>>>> sip.cfg <<<<\n" . $sipextcfg . "\n";

		$cntr++;
   }
   print LOGF "Processed " . $cntr . " DNs, time " . localtime(time) . "\n";
}   

sub ProcessConfigurationAgent
{
   my $ttl = "\n; ######## Voice Mail Boxes for the Agents #######\n\n";
   push(@voicemail_buff,$ttl);

   # Retrieves all necessary objects from Configuration Server. 
   my $qry = $cfgagentquery;
   my $agents_dataset = $s->get(SOAP::Data->name(query => $qry )); 
   my $cntr = 0;
   my $vmboxcfg = '';

   # VoiceMail Box options 
   my $gvma_mailbox = '';
   my $gvma_pasword = '';
   my $gvma_name = '';
   my $gvma_email = '';
   my $gvma_pager_email = '';
   my $gvma_options = '';
   
   print LOGF "Executing query: " . $qry . "\n";
   print LOGF "Retrieving Extensions, started: " . localtime(time) . "\n";

   foreach my $agent ($agents_dataset->valueof(GVMA_CFGRESPONSEPATHAGENT)) 
   {
		print LOGF "Processing Agent: " . $agent->name->value . " ...";

		# Voice mail box for an agent must be explicitly specified 
		$gvma_mailbox = '';							# empty
		$gvma_pasword = '';							# empty
		$gvma_name = '';							# empty	
		$gvma_email = '';							# empty
		$gvma_pager_email = '';						# empty
		$gvma_options = '';							# empty 
		
		if( defined($agent->userProperties) && defined($agent->userProperties->list_pair) )
		{
			foreach my $section ($agent->userProperties->list_pair )   
			{
     				if( $section->key eq $gvma_opt_sectionname )
     				{
						foreach my $option ($section->str_pair )   
						{
							if( $option->{'_attr'}->{'key'} eq $gvma_opt_mailbox )
							{
								$gvma_mailbox = $option->{'_attr'}->{'value'};
							}
							elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_pasword )
							{
								$gvma_pasword = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_name )
							{
								$gvma_name = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_email )
							{
								$gvma_email = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_pager_email )
							{
								$gvma_pager_email = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_options )
							{
								$gvma_options = $option->{'_attr'}->{'value'};
							}
						}
     				}
			}
		}

		# Map options to VoiceMail Box configuration line 
		if( $gvma_mailbox ne '' )
		{
			$vmboxcfg = $gvma_mailbox . " => ";
			$vmboxcfg = $vmboxcfg . $gvma_pasword . ",";
			$vmboxcfg = $vmboxcfg . $gvma_name . ",";
			$vmboxcfg = $vmboxcfg . $gvma_email . ",";
			$vmboxcfg = $vmboxcfg . $gvma_pager_email . ",";
			$vmboxcfg = $vmboxcfg . $gvma_options . "\n";
			push(@voicemail_buff,$vmboxcfg);
			print LOGF "\n>>>> voicemail.cfg <<<<\n" . $vmboxcfg . "\n";

			# Map options to Asterisk SIP extension configuration 
			$sipextcfg = "[" . $gvma_mailbox . "]\n";
			$sipextcfg = $sipextcfg . "type=friend\n";
			$sipextcfg = $sipextcfg . "host=dynamic\n";
			$sipextcfg = $sipextcfg . "mailbox=" . $gvma_mailbox . "\n\n";
			push(@sip_buff,$sipextcfg);
			print LOGF "\n>>>> sip.cfg <<<<\n" . $sipextcfg . "\n";
		}
		else
		{
			print LOGF "IGNORED\n";
		}
		
		$cntr++;
   }

   print LOGF "Processed " . $cntr . " Agents, time " . localtime(time) . "\n";
}   

sub ProcessConfigurationAgentGroup
{
   my $ttl = "\n; ######## Voice Mail Boxes for the Agent Groups #######\n\n";
   push(@voicemail_buff,$ttl);

   # Retrieves all necessary objects from Configuration Server. 
   my $qry = $cfgagentgroupquery;
   my $ag_dataset = $s->get(SOAP::Data->name(query => $qry )); 
   my $cntr = 0;
   my $vmboxcfg = '';

   # VoiceMail Box options 
   my $gvma_mailbox = '';
   my $gvma_pasword = '';
   my $gvma_name = '';
   my $gvma_email = '';
   my $gvma_pager_email = '';
   my $gvma_options = '';
   
   print LOGF "Executing query: " . $qry . "\n";
   print LOGF "Retrieving Extensions, started: " . localtime(time) . "\n";

   foreach my $ag ($ag_dataset->valueof(GVMA_CFGRESPONSEPATHAGENTGROUP)) 
   {
		print LOGF "Processing Agent Group: " . $ag->name->value . " ...";

		# Voice mail box for an agent must be explicitly specified 
		$gvma_mailbox = '';							# empty
		$gvma_pasword = '';							# empty
		$gvma_name = '';							# empty	
		$gvma_email = '';							# empty
		$gvma_pager_email = '';						# empty
		$gvma_options = '';							# empty 
		
		if( defined($ag->userProperties) && defined($ag->userProperties->list_pair) )
		{
			foreach my $section ($ag->userProperties->list_pair )   
			{
     				if( $section->key eq $gvma_opt_sectionname )
     				{
						foreach my $option ($section->str_pair )   
						{
							if( $option->{'_attr'}->{'key'} eq $gvma_opt_mailbox )
							{
								$gvma_mailbox = $option->{'_attr'}->{'value'};
							}
							elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_pasword )
							{
								$gvma_pasword = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_name )
							{
								$gvma_name = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_email )
							{
								$gvma_email = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_pager_email )
							{
								$gvma_pager_email = $option->{'_attr'}->{'value'};
							}
						    elsif( $option->{'_attr'}->{'key'} eq $gvma_opt_options )
							{
								$gvma_options = $option->{'_attr'}->{'value'};
							}
						}
     				}
			}
		}

		# Map options to VoiceMail Box configuration line 
		if( $gvma_mailbox ne '' )
		{
			$vmboxcfg = $gvma_mailbox . " => ";
			$vmboxcfg = $vmboxcfg . $gvma_pasword . ",";
			$vmboxcfg = $vmboxcfg . $gvma_name . ",";
			$vmboxcfg = $vmboxcfg . $gvma_email . ",";
			$vmboxcfg = $vmboxcfg . $gvma_pager_email . ",";
			$vmboxcfg = $vmboxcfg . $gvma_options . "\n";
			push(@voicemail_buff,$vmboxcfg);
			print LOGF "\n>>>> voicemail.cfg <<<<\n" . $vmboxcfg . "\n";

			# Map options to Asterisk SIP extension configuration 
			$sipextcfg = "[" . $gvma_mailbox . "]\n";
			$sipextcfg = $sipextcfg . "type=friend\n";
			$sipextcfg = $sipextcfg . "host=dynamic\n";
			$sipextcfg = $sipextcfg . "mailbox=" . $gvma_mailbox . "\n\n";
			push(@sip_buff,$sipextcfg);
			print LOGF "\n>>>> sip.cfg <<<<\n" . $sipextcfg . "\n";
		}
		else
		{
			print LOGF "IGNORED\n";
		}
		
		$cntr++;
   }

   print LOGF "Processed " . $cntr . " Agent Groups, time " . localtime(time) . "\n";
}   

##################################################################
#
# GetCfgOption - helper function to retrieve options from 
#   the configuration file. 
#
# par1: section name
# par2: option name
#
# ret1: option value if property found, -1 otherwise
sub GetCfgOption
{
  my ($lkupSectionName, $lkupOptionName) = @_;
  my $section_name = 0; 
  open FDB, CFGFILENAME or die "Unable to open: $! \n";    

  while (<FDB>) 
  { 
      $_ = strip_CRLF($_); next unless $_;
      if (m/^#/) { next; }       
      elsif (m/^\[(\w+)\]/){$section_name = $1; 
       }
      elsif ($section_name){
        if (m/^([^= ]+)\s*=\s*([^\n]+)$/){ 
         ($optname, $optval) = ($1,$2);
         if (($section_name =~ /$lkupSectionName/) && ($optname =~ /$lkupOptionName/)) {
          close(FDB); 
          return ($optval);    
         }
        }
        elsif (length($_) > 1){          
          ($optname, $optval) = ($_, 1);  
        }
      }
      else { print LOGF "ERROR in config file: $_"; }     
   }
 close(FDB);
}

sub strip_CRLF # also strips whitespaces at the end of the line
{
  my $str = shift; return $str =~ /^([^\r\n]*?)\s*\r?\n?$/ ? $1 : "";
}

sub find_elem($$)
{ 
  my ($A, $elem) = @_; for my $k (0..$#$A) {
                         return $k if ($$A[$k] eq $elem);
                       }
                       return -1; 
}

sub ChkEnv{
    $reload = 0 ;
    print LOGF "Environment check.\n\n";
      $output = `ps -C asterisk | grep asterisk >&1`;
   if (!$output)
   {
    print LOGF "Asterisk is not running.\n";
    }
    else
    {
    $reload = 1;
    print LOGF "Asterisk is running:\n PID\tTTY\tTIME\tCMD\n". $output ."\n";
    }
  open CFG, CFGFILENAME or die "Error: Unable to open " . CFGFILENAME . " : $!, Exiting\n";
  print LOGF "Configuration file found.\n\n";
  close CFG;  
}
