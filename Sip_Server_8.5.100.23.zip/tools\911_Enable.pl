#!/usr/bin/perl -w
#!perl.exe 
################################################################################################
# Genesys Telecommunication Labaratories, Inc.                                                 # 
# An Alcatel-LucentCompany                                                                           #
#                                                                                              #
# Uses the SOAP:::Lite package to connect to Configuration Server on SOAP port in order to     #
# retrieve TServers data.                                                                      #
#                                                                                              #
################################################################################################
use HTTP::Cookies;
#use SOAP::Lite+trace; #Don't use in production
use SOAP::Lite;
use File::Copy;
use File::Basename;
use Net::Telnet ();
use Net::FTP;

use constant CFGSERVERSECTION                  => 'cfgserver';
use constant CFGSERVEROPTIONHOST               => 'host';
use constant CFGSERVEROPTIONPORT               => 'port';
use constant CFGSERVEROPTIONUSER               => 'username';
use constant CFGSERVEROPTIONPSSW               => 'password';
use constant CFGSERVERDNQUERY                 => 'dnquery';
use constant CFGSERVERTENANT                    => 'tenant';
use constant CFGSERVERSWITCH                    => 'switch';
use constant DN_CFGRESPONSEPATHDN             => '/Envelope/Body/getResponse/result/CfgData/CfgDN';

use constant EGWSECTION                          => 'egw';
use constant EGWOPTIONHOST                       => 'host';
use constant EGWOPTIONUSER                       => 'username';
use constant EGWOPTIONPSSW                       => 'password';

use constant EGW_BATCH_EXT                    => 'txt';



my $scriptbase = basename($0,".pl");
my $cfgfile2 = $scriptbase . ".cfg";
my $cfgfile1 = '';
if ($#ARGV >= 0)
{
   $cfgfile1 = $ARGV[0];
}

my $cfgfilename;
if(open (CFG, $cfgfile1))
{
  close(CFG);
  $cfgfilename = $cfgfile1; 
}
else
{
  open (CFG, $cfgfile2) or die "No configuration available '$cfgfile1' '$cfgfile2'\n";
  close (CFG);
  $cfgfilename = $cfgfile2;
}

my $logbase = basename($cfgfilename,".cfg") . "_";
my $batchbase = basename($cfgfilename,".cfg");


my $newBatchName = $batchbase . "." . EGW_BATCH_EXT;
my $oldBatchName = $batchbase . "_." . EGW_BATCH_EXT;

print  "BATCH: old/new:  '$oldBatchName'/'$newBatchName' \n";

 
# log file setup 
my $log_file;
my ($Second, $Minute, $Hour, $Day, $Month, $Year, $WeekDay, $DayOfYear, $IsDST) = localtime(time) ;
$Month ++ ;
$Year += 1900 ;
my $datestamp = $Month."-".$Day."-".$Year."-".$Hour."-".$Minute."-".$Second;
$log_file = ">" . $logbase . $datestamp . ".log";
open(LOGF,$log_file) or die("ERROR: Can not open $log_file because $!\n");
print  "LOG:  $log_file\n";

#Configuration login params  
my ($host, $port, $user, $passwd, $cfgdnquery, $cfgtenant, $cfgswitch);

print LOGF "\n###########################################################################";
print LOGF "\n# Genesys Configuration Utility for 911 Enable Emergency Gateway.         #";
print LOGF "\n#  Version 8.0.000.01. An Alcatel-Lucent Company                          #";
print LOGF "\n###########################################################################";
print LOGF "\n\n";


# ###############################################################################
# Retrieve parameters from configuration file

$host = GetCfgOption(CFGSERVERSECTION, CFGSERVEROPTIONHOST);
$port = GetCfgOption(CFGSERVERSECTION, CFGSERVEROPTIONPORT);
$user = GetCfgOption(CFGSERVERSECTION, CFGSERVEROPTIONUSER);
$passwd = GetCfgOption(CFGSERVERSECTION,CFGSERVEROPTIONPSSW); 
$cfgtenant =  GetCfgOption(CFGSERVERSECTION, CFGSERVERTENANT);
$cfgswitch =  GetCfgOption(CFGSERVERSECTION, CFGSERVERSWITCH);
$cfgdnquery = 'CfgTenant[@name=\'' . $cfgtenant . '\']/switches/CfgSwitch[@name=\'' . $cfgswitch . '\']/DNs/CfgDN[@type=\'1\']';
print "CFGDNQUERY: '$cfgdnquery' \n";
$egwhost      = GetCfgOption(EGWSECTION,EGWOPTIONHOST);
$egwuser      = GetCfgOption(EGWSECTION,EGWOPTIONUSER);
$egwpasswd    = GetCfgOption(EGWSECTION,EGWOPTIONPSSW);

print "EGW: host='$egwhost' user='$egwuser' passwd='$egwpasswd'\n"; 

my $end_point = "http://".$host.":".$port;

# ###############################################################################
# Connect to Config Server 

print LOGF "\nConnecting to Configurtion Server on host=$host, soap-port=$port..\n";
$cookie_jar = HTTP::Cookies->new(ignore_discard => 1);
$s = SOAP::Lite
  ->proxy($end_point,cookie_jar => $cookie_jar )
  ->deserializer(SOAP::Custom::XML::Deserializer->new);
my $soap_response = $s->registerInternal( SOAP::Data->name(userName => $user),
                                          SOAP::Data->name(userPassword => $passwd),	
                                          SOAP::Data->name(applicationName => 'default') );
# tbd: check reg result 
print LOGF "\nConnected to configuration server.\n";
 

# ###############################################################################   

# Create backup copies

my %endpoints = ();
# Process configuration data, store result in buffers
ProcessConfigurationDN();
print LOGF "Configuration processed ...\n";
my $epNum =  scalar keys( %endpoints);
print "EXTENSIONS: $epNum\n";
$epNum || die  ("There is no DN found on switch $cfgswitch \n");
# if old batch file exists rename it
if (-f $newBatchName) {
  copy ($newBatchName, $oldBatchName);
} 
# create new batch file
open (NEWF,">",$newBatchName) or die ("Cannot open file to write $newBatchName");
# fill out new batch file
foreach $key (keys %endpoints) 
{
  my $ipaddr = $endpoints{$key};
  print NEWF "1;";             # Operation Add | update
  print NEWF $cfgswitch . ";"; # The name of PBX to which the endpoints will be assigned
  print NEWF $key . ";";       # The extension of the phone
  print NEWF ";";              # MAC address - empty for now
  print NEWF ";";              # ERL ID - empty for now
  print NEWF  $ipaddr . ";";   # IP address
  print NEWF  ";";             # Display name epmty for now
  print NEWF  "";             # Timestamp of discovery
  print NEWF   "\n";
}
#close new batch file and log file
close (NEWF);

# FTP batch file to emergency gateway
$ftp = Net::FTP->new($egwhost) or die "Cannot connect to '$egwhost'\n";
print LOGF "FTP: Connected to host '$egwhost'\n";
$ftp->login($egwuser,$egwpasswd) or die "Cannot loging as '$egwuser'\n";
print LOGF "FTP: logged in as '$egwuser'\n";
$ftp->put($newBatchName) or die "Cannot upload teh file '$newBatchName'\n";
$ftp->quit;
print LOGF "FTP: uploaded  '$newBatchName'\n";
print LOGF "JOB: completed\n";
close (LOGF);
print "JOB: completed\n";
exit 0;
 
sub ProcessConfigurationDN
{
   # Retrieves all necessary objects from Configuration Server. 
   my $qry = $cfgdnquery;
   
   my $dns_dataset = $s->get(SOAP::Data->name(query => $qry )); 
   my $cntr = 0;
   
   my $dnname = '';
   my $ipaddress = '';
   
   print LOGF "Executing query: " . $qry . "\n";
   print LOGF "Retrieving Extensions, started: " . localtime(time) . "\n";
   foreach my $dn ($dns_dataset->valueof(DN_CFGRESPONSEPATHDN)) 
   {
		print LOGF "\nExtension: " . $dn->name->value;

    $dnname =  $dn->name->value;		# the same as DN
		$ipaddress = '';

		
		if( defined($dn->userProperties) && defined($dn->userProperties->list_pair) )
		{
			foreach my $section ($dn->userProperties->list_pair )   
			{
					# print LOGF "\tProcessing Section: " . $section->key . "\n";
     				if( $section->key eq 'TServer' )
     				{
  						foreach my $option ($section->str_pair )   
  						{
     						if( $option->{'_attr'}->{'key'} eq 'contact' )
  							{
  								$contact = $option->{'_attr'}->{'value'};
   								if ($contact =~ /\d+\.\d+\.\d+\.\d+/)
  								{ # decimal ip address found could be extracted
                     $ipaddress =  $&;
                  		print LOGF "\n     Contact: " .$ipaddress;                     
                   }
  							}
  						}
     				}
			}
		}
    $endpoints{$dnname} = $ipaddress;

		$cntr++;
   }
   print LOGF "\nProcessed " . $cntr . " DNs, time " . localtime(time) . "\n";
}

##################################################################
#
# GetCfgOption - helper function to retrieve options from 
#   the configuration file. 
#
# par1: section name
# par2: option name
#
# ret1: option value if property found, -1 otherwise
sub GetCfgOption
{
  my ($lkupSectionName, $lkupOptionName) = @_;
  my $section_name = 0; 
  open FDB, $cfgfilename or die "Unable to open: $! \n";    

  while (<FDB>) 
  { 
      $_ = strip_CRLF($_); next unless $_;
      if (m/^#/) { next; }       
      elsif (m/^\[(\w+)\]/){$section_name = $1; 
       }
      elsif ($section_name){
        if (m/^([^= ]+)\s*=\s*([^\n]+)$/){ 
         ($optname, $optval) = ($1,$2);
         if (($section_name =~ /$lkupSectionName/) && ($optname =~ /$lkupOptionName/)) {
          close(FDB); 
          return ($optval);    
         }
        }
        elsif (length($_) > 1){          
          ($optname, $optval) = ($_, 1);  
        }
      }
      else { print LOGF "ERROR in config file: $_"; }     
   }
 close(FDB);
}

sub strip_CRLF # also strips whitespaces at the end of the line
{
  my $str = shift; return $str =~ /^([^\r\n]*?)\s*\r?\n?$/ ? $1 : "";
}
